var app = angular.module('myApp', []);

app.controller("mainController", function ($scope, $http) {
    $scope.apiKey = "c18295e11a0927b9b740fab094753b83";
    $scope.results = [];

    $scope.init = function () {
        //API requires a start date
        var today = new Date();
        //Create the date string and ensure leading zeros if required
        var apiDate = today.getFullYear() + ("0" + (today.getMonth() + 1)).slice(-2) + "" + ("0" + today.getDate()).slice(-2);
        $http.jsonp('http://api.trakt.tv/calendar/premieres.json/' + $scope.apiKey + '/' + apiDate + '/' + 30 + '/?callback=JSON_CALLBACK').success(function (data) {
            $scope.results = data;
        }).error(function (error) {
        });
    };
});

